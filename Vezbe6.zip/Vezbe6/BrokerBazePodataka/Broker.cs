﻿using Domen;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrokerBazePodataka
{
    public class Broker
    {
        private SqlConnection connection;
        private SqlTransaction transaction;

        public Broker()
        {
            connection = new SqlConnection(@"");
        }

        public void OtvoriKonekciju()
        {
            connection.Open();
        }

        public void ZatvoriKonekciju()
        {
            connection.Close();
        }

        public void PokreniTransakciju()
        {
            transaction = connection.BeginTransaction();
        }

        public void Commit()
        {
            transaction.Commit();
        }

        public void Rollback()
        {
            transaction.Rollback();
        }


        /*
         *   command.CommandText = "select p.Id, p.Naziv, Cena, Proizvodjac, pr.Naziv from Proizvod p join Proizvodjac pr on (p.Proizvodjac=pr.Id)";
                  SqlCommand commandRacun = new SqlCommand("insert into Racun output inserted.Id values (@Datum, @Korisnik)", connection, transaction);
                  komanda.Parameters.Add("@PredmetId", SqlDbType.Int).Value = p.Predmet.PredmetId;
					komanda.Parameters.Add("@DatumPrijave", SqlDbType.Date).Value = p.DatumPrijave;
					komanda.Parameters.Add("@StudentId", SqlDbType.VarChar).Value = p.Student.Indeks;
					komanda.Parameters.Add("@DatumUnosaPrijave", SqlDbType.Date).Value = new DateTime();
			// select * from Tabela join Tabela2 on (t1.Id= t2.Id) where 
            // insert into Tabela out inserted.Id values()
            // update Tabela set Kolona = Kolona-1 where 
        */





    }

}

