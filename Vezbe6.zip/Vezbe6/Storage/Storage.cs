﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domen;

namespace Storage
{
    public class Storage
    {
        private List<Korisnik> korisnici;

        public Storage()
        {
            korisnici = new List<Korisnik>() {
                new Korisnik {
                Ime = "Mika",
                Prezime = "Peric",
                KorisnickoIme= "mika",
                Password = "mika"
            } };

            Korisnik k = new Korisnik();
            k.Ime = "Pera";
            k.Prezime = "Peric";
            k.KorisnickoIme = "pera";
            k.Password = "pera";

            Korisnik k1 = new Korisnik()
            {
                Ime = "Zika",
                Prezime = "Peric",
                KorisnickoIme = "zika",
                Password = "zika"
            };
            korisnici.Add(k);
            korisnici.Add(k1);
        }

        public List<Korisnik> VratiSve()
        {
            return korisnici;
        }
    }
}
